/* assets/script.js */
document.addEventListener('DOMContentLoaded', function() {
    alert('Wtyczka została załadowana!');
});
