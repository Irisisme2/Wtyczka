<?php
/*
Plugin Name: Ocena
Description: Wtyczka do oceniania postów.
Version: 1.0
Author: Wiktoria Jarema
*/

// Funkcja do dodawania pola oceny do postów
if (!function_exists('dodaj_pole_oceny')) {
    function dodaj_pole_oceny() {
        add_meta_box('ocena_postu', 'Ocena Postu', 'render_pole_oceny', 'post', 'normal', 'high');
        wp_enqueue_style('moja-wtyczka-style', plugin_dir_url(__FILE__) . 'assets/style.css');
        wp_enqueue_script('moja-wtyczka-script', plugin_dir_url(__FILE__) . 'assets/script.js', array('jquery'), null, true);
    }
}

function render_pole_oceny($post) {
    $ocena = get_post_meta($post->ID, 'ocena', true);
    ?>
    <label for="ocena">Ocena:</label>
    <select name="ocena" id="ocena">
        <?php
        for ($i = 1; $i <= 5; $i++) {
            echo '<option value="' . $i . '" ' . selected($ocena, $i, false) . '>' . $i . '</option>';
        }
        ?>
    </select>
    <?php
}

// Funkcja do zapisywania oceny postu
function zapisz_ocene_postu($post_id) {
    if (array_key_exists('ocena', $_POST)) {
        update_post_meta($post_id, 'ocena', $_POST['ocena']);
    }
}

// Funkcja do wyświetlania średniej oceny postów na stronie
function wyswietl_srednia_ocena() {
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => -1,
    );

    $posts = new WP_Query($args);
    $suma_ocen = 0;
    $liczba_postow = $posts->found_posts;

    while ($posts->have_posts()) {
        $posts->the_post();
        $suma_ocen += intval(get_post_meta(get_the_ID(), 'ocena', true));
    }

    $srednia_ocena = $liczba_postow > 0 ? round($suma_ocen / $liczba_postow, 2) : 0;

    echo '<p>Średnia ocena postów: ' . $srednia_ocena . '</p>';
    wp_reset_postdata();
}

add_action('add_meta_boxes', 'dodaj_pole_oceny');
add_action('save_post', 'zapisz_ocene_postu');
add_shortcode('wyswietl_srednia_ocena', 'wyswietl_srednia_ocena');
?>
